# Media Embedder
Embed a wide variety of media in PNGs and WebMs on 4chan

## Installation
Make sure you have a userscript manager installed, and have installed [4chan X](https://www.4chan-x.net/#firefox). Then click [here](https://git.coom.tech/Zip/Media-Embedder/raw/branch/master/mediaembedder.user.js).

## Usage
When you hover your cursor over a post that has embedded media, a golden button labeled "Decode Embed" will appear. Clicking it will reveal the embedded media.

## Goal
The goal of this script is to rewrite various media embedding tools without the need for bloat like NPM modules and cancer like TypeScript.

## Compatibility
This script is compatible with files created by [PNG Extra Embedder](https://git.coom.tech/coomdev/PEE). The main difference is that this script is written in pure JavaScript, and actually works with most userscript managers. It has been tested on Firefox with Greasemkey and Violentmonkey, and on Ungoogled Chromium with Violentmonkey.
