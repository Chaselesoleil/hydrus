// ==UserScript==
// @name         Media Embedder
// @version      0.6.5
// @description  Embed a wide variety of media in PNGs and WebMs on 4chan
// @author       Zip
// @match        https://boards.4channel.org/*
// @match        https://boards.4chan.org/*
// @grant        GM_xmlhttpRequest
// @grant        GM.xmlHttpRequest
// @grant        GM_registerMenuCommand
// @grant        GM.registerMenuCommand
// @updateURL    https://git.coom.tech/Zip/Media-Embedder/raw/branch/master/mediaembedder.user.js
// @downloadURL  https://git.coom.tech/Zip/Media-Embedder/raw/branch/master/mediaembedder.user.js
// @license      GPL-3.0
// @icon         data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA0OCA0OCIgeG1sbnM6dj0iaHR0cHM6Ly92ZWN0YS5pby9uYW5vIj48cGF0aCBkPSJNMTQgNDVjLS4xMjcgMC0uMjI0LS4wNDYtLjMyMi0uMTUzQzEzLjEwNyA0NC4yMjEgMTMgNDIuNzA4IDEzIDQxdi0xbC0xIC41djIuMDJjLjAzNCAxLjA5My4zMzcgMi4zNC45MzkgMyAuMjg2LjMxNC42NTMuNDggMS4wNjEuNDhoMCAxdi0xaC0xeiIgZmlsbD0iIzc4OTA5YyIvPjxwYXRoIGQ9Ik0xMyAzN2wtMiAxdi45NDRoMCAwVjM5bDItMXoiIGZpbGw9IiNiMGJlYzUiLz48cGF0aCBkPSJNMTMgMzhsLTIgMXYxbDItMXptMC0ybC0yIDF2Ljk0NGguMDAxSDExVjM4bDItMXoiIGZpbGw9IiM3ODkwOWMiLz48cGF0aCBkPSJNMTMgMzlsLTIgLjk5NVY0MWwyLTF6bTAtNmwtMiAxdi45NDRoMCAwVjM1bDItMXoiIGZpbGw9IiNiMGJlYzUiLz48cGF0aCBkPSJNMTMgMzRsLTIgMXYxbDItMXptMC0ycy4wNjMtLjAxNi0xIC41LTEgMS40NDQtMSAxLjQ0NGgwVjM0bDItMXYtMXoiIGZpbGw9IiM3ODkwOWMiLz48cGF0aCBkPSJNMTMgMzVsLTIgLjk5NVYzN2wyLTF6bTE5IDJIMTZsLTIgMTBoMiA4IDggMnoiIGZpbGw9IiNiMGJlYzUiLz48cGF0aCBkPSJNMjMgNDNsLTIgNGg2bC0yLTR6IiBmaWxsPSIjMzc0NzRmIi8+PHBhdGggZD0iTTM1Ljc4NSAyNC43MTdhNC40MiA0LjQyIDAgMCAxIDEuMDMtMi4wNjljLjQxNC0uNDYzIDEuMDc4LS44NDQgMS42MTEtLjUzOS41MTIuMjk0LjU3NCAxLjAxNi41NzQgMS42MjJsLS4wMDkgMy4xNDFjLS4wMDUuNTc0LS4wMTQgMS4xNTctLjE3OSAxLjcwNS0uMTc1LjU3OS0uNTE1IDEuMDg3LS44NTkgMS41NzlsLS44NzMgMS4yMDljLS4yNjEuMzQ5LS42MzUuNzM1LTEuMDQ0LjYxMi0uMTQ2LS4wNDQtLjI2Ni0uMTQ4LS4zODEtLjI1bC0uNjU0LS41NzUuNzg0LTYuNDM1em0tMjMuNTcgMGE0LjQyIDQuNDIgMCAwIDAtMS4wMy0yLjA2OWMtLjQxNC0uNDYzLTEuMDc4LS44NDQtMS42MTEtLjUzOS0uNTEyLjI5NC0uNTc0IDEuMDE2LS41NzQgMS42MjJsLjAwOSAzLjE0MWMuMDA1LjU3NC4wMTQgMS4xNTcuMTc5IDEuNzA1LjE3NS41NzkuNTE1IDEuMDg3Ljg1OSAxLjU3OWwuODczIDEuMjA5Yy4yNjEuMzQ5LjYzNS43MzUgMS4wNDQuNjEyLjE0Ni0uMDQ0LjI2Ni0uMTQ4LjM4MS0uMjVsLjY1NC0uNTc1LS43ODQtNi40MzV6IiBmaWxsPSIjZmZhNzI2Ii8+PHBhdGggZD0iTTM4IDI2YzAgMi4wODMtMSAzLTEgM3YtMmExIDEgMCAxIDEgMC0yIDEgMSAwIDAgMSAxIDF6IiBmaWxsPSIjZmI4YzAwIi8+PHBhdGggZD0iTTIyIDQ0Yy0yLjE4OCAwLTEwLTctMTAtOVYxNHMuMjkyLTggMTItOCAxMiA4IDEyIDh2MjFjMCAyLjEyNS04IDktMTAgOWgtNHoiIGZpbGw9IiNmZmI3NGQiLz48cGF0aCBkPSJNMjAgMzVzMS40MTctMSA0LTEgNCAxIDQgMSIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjZmI4YzAwIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1taXRlcmxpbWl0PSIxMCIvPjxwYXRoIGQ9Ik0yMiAxYy00LjA4MyAwLTEyIDMuMjUtMTIgMTN2OGwzIDN2LTZzLS43NS0xMC4wODMgNC43NDEtMTEuOTM4QzE4Ljg1NSA2LjY4NSAyMCA3LjgyNCAyMCA5aDBjMCAuNTUyLjQ0OC43ODggMSAuNzg4aDMgM2ExIDEgMCAwIDAgMS0xdi0uMDA2YTEuNzkgMS43OSAwIDAgMSAyLjI1OS0xLjcyMUMzNiA4LjY2NyAzNSAxOSAzNSAxOXY2bDMtM3YtOWMwLTYuODA4LTUuMDgzLTEwLTEwLTEwLTEuMTY3LTEuOTE3LTQuODIxLTItNi0yeiIgZmlsbD0iIzQyNDI0MiIvPjxwYXRoIGQ9Ik0xMiAyNWgtMWMtLjU1IDAtMSAuNDUtMSAxdjFjMCAuNTUuNDUgMSAxIDFoMXYtM3oiIGZpbGw9IiM1NDZlN2EiLz48cGF0aCBkPSJNMTMgNDBsLTIgMWMwIDEgMSAuNSAxIC41bDEtLjV2LTF6IiBmaWxsPSIjNzg5MDljIi8+PHBhdGggZD0iTTI2IDIxbDgtM20tMjAgMGw4IDMiIGZpbGw9Im5vbmUiIHN0cm9rZS13aWR0aD0iMiIgc3Ryb2tlLW1pdGVybGltaXQ9IjEwIiBzdHJva2U9IiM1NDZlN2EiLz48ZyBmaWxsPSIjNDI0MjQyIj48cGF0aCBkPSJNMTYgMjIuMDAxaDE2djFIMTZ6Ii8+PHBhdGggZD0iTTE0LjI5OSAyMC41MzdzMS40MjItLjM5MyAzLjM0MS0uNTA5IDQuMDUxLjE2OSA0LjA1MS4xNjljLjgwOS4yNDEgMS41MDMuNzExIDEuMjU1IDEuNDhsLS45MTEgMi44MjJzLS4zNzEgMS4xMDMtMS40ODYgMS4yNzhjLTEuMi4xODgtMy45MDEuMjktNC44OTEuMTc0LS44Mi0uMDk2LTEuNzM0LS4xMTYtMi4wNDMtLjk4Ny0uMTAxLS4yODQtLjMzMi0xLjYxMy0uNTgtMi42OS0uMTg3LS44MTIuMzg5LTEuNjA0IDEuMjY0LTEuNzM3em0xOS40MDIgMHMtMS40MjItLjM5My0zLjM0MS0uNTA5LTQuMDUxLjE2OS00LjA1MS4xNjljLS43NDYuMTE2LTEuNTAzLjcxMS0xLjI1NSAxLjQ4bC45MTEgMi44MjJzLjM3MSAxLjEwMyAxLjQ4NiAxLjI3OGMxLjIuMTg4IDMuOTAxLjI5IDQuODkxLjE3NC44Mi0uMDk2IDEuNzM0LS4xMTYgMi4wNDMtLjk4Ny4xMDEtLjI4NC4zMzItMS42MTMuNTgtMi42OS4xODctLjgxMi0uMzg5LTEuNjA0LTEuMjY0LTEuNzM3eiIvPjwvZz48L3N2Zz4=
// ==/UserScript==

// Media Embedder, Embed a wide variety of media in PNGs and WebMs on 4chan
// Copyright (C) 2022 Zip

// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.

// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <https://www.gnu.org/licenses/>.


const registerMenuCommand = typeof GM_registerMenuCommand != 'undefined' ? GM_registerMenuCommand : (GM ? GM.registerMenuCommand : GM_registerMenuCommand);

registerMenuCommand('Decode File', function(){
    const uploadButton = document.createElement('div');
    uploadButton.textContent = 'Click here or drop file to decode';
    uploadButton.setAttribute('style', 'z-index: 2147483647; color: white; background-color: black; text-align: center; line-height: 100vh; vertical-align: middle; font-size: large; position: fixed; width: 100vw; height: 100vh; top: 0px; left: 0px;');
    async function localDecode(file){
        if(!file) return;
        const fileBuffer = await file.arrayBuffer();
        const uploadData = new Uint8Array(fileBuffer);
        const dataCopy = new Uint8Array(uploadData.length);
        dataCopy.set(uploadData);

        const downloadButton = document.createElement('a');
        document.body.appendChild(downloadButton);

        const fileExt = file.name.split('.').pop();
        let finalBlob;
        switch(fileExt.toLowerCase()){
            case 'webm':
                let extracted = extractFromWebM(dataCopy);
                if(!extracted){
                    alert("No embedded data");
                    downloadButton.remove();
                    return;
                }
                downloadButton.download = extracted.filename;
                finalBlob = new Blob([extracted.fileData], {type: getFileType(extracted.fileData)?.mime});
                downloadButton.href = URL.createObjectURL(finalBlob);
                break;
            case 'png':
                let png = new PNG(dataCopy);
                let hasCoomChunk = false;
                let metaDecoder = new TextDecoder();
                let lastIDATData;
                for(let chunk of png.chunks){
                    if(chunk.type == 'tEXt') if(metaDecoder.decode(chunk.data) == 'CUM\u00000') hasCoomChunk = true;
                    if(chunk.type == 'IDAT') lastIDATData = chunk.data;
                }
                if(!hasCoomChunk){
                    alert("No embedded data");
                    downloadButton.remove();
                    return;
                }
                let filenameSize = lastIDATData[0] | (lastIDATData[1] << 8) | (lastIDATData[2] << 16) | (lastIDATData[3] << 24);
                let filenameBin = lastIDATData.slice(4, 4 + filenameSize);
                downloadButton.download = new TextDecoder('utf-8').decode(filenameBin);
                let fileData = lastIDATData.slice(4 + filenameSize);
                finalBlob = new Blob([fileData], {type: getFileType(fileData)?.mime});
                break;
            default:
                alert("Not a PNG or WebM");
                downloadButton.remove();
                return;
        }

        downloadButton.href = URL.createObjectURL(finalBlob);
        downloadButton.click();
        downloadButton.remove();
    }
    uploadButton.onclick = async function(){
        uploadButton.remove();
        const uploadedFile = await uploadNewFile();
        localDecode(uploadedFile);
    }
    uploadButton.ondrop = function(event){
        event.preventDefault();
        uploadButton.remove();
        localDecode(event.dataTransfer.files[0]);
    }
    document.body.appendChild(uploadButton);
});

function createCheckbox(text, info, callback, value){
    const checkBoxLabel = document.createElement('label');
    checkBoxLabel.textContent = text;
    checkBoxLabel.title = info;
    const checkBox =  document.createElement('input');
    checkBox.type = 'checkbox';
    checkBox.onchange = callback;
    checkBox.checked = value;
    checkBoxLabel.prepend(checkBox);

    return checkBoxLabel;
}

const defaultHashSources = [
    {name: "gelbooru", url: "https://gelbooru.com/index.php?page=dapi&s=post&q=index&json=1&tags=md5:", width: "sample_width", height: "sample_height"},
    {name: "yande.re", url: "https://yande.re/post.json?tags=md5%3A", width: "sample_width", height: "sample_height"},
    {name: "sankaku", url: "https://capi-v2.sankakucomplex.com/posts/keyset?tags=md5:", width: "sample_width", height: "sample_height"},
    {name: "rule34", url: "https://api.rule34.xxx/index.php?page=dapi&s=post&q=index&json=1&tags=md5:", width: "sample_width", height: "sample_height"},
    {name: "danbooru", url: "https://danbooru.donmai.us/posts.json?tags=md5%3A", width: "image_width", height: "image_height"},
    {name: "lolibooru", url: "https://lolibooru.moe/post.json?tags=md5:", width: "sample_width", height: "sample_height"},
];

function createSettings(){
    const settingsBox = document.createElement('div');
    settingsBox.setAttribute('style', 'color: white; background-color: black; border: solid 2px gray; visibility: hidden; position: fixed; padding: 10px;');

    const settingsTitle = document.createElement('h3');
    settingsTitle.textContent = 'Media Embedder Settings';
    settingsTitle.style.cursor = 'pointer';
    settingsBox.appendChild(settingsTitle);

    const closeButton = document.createElement('label');
    closeButton.textContent = '🗙';
    closeButton.setAttribute('style', 'position: absolute; top: 0px; right: 0px; padding: 4px;');
    closeButton.onclick = function(){
        settingsBox.style.visibility = 'hidden';
    }
    settingsBox.appendChild(closeButton);

    const defaultSettings = {
        '4chan-preload-embeds': false,
        '4chan-loop-video': true,
        '4chan-loop-audio': true,
        '4chan-float-embeds': false,
        '4chan-load-file-embeds': true,
        '4chan-load-catbox-embeds': true,
        '4chan-load-hash-embeds': true
    }
    for(let setting in defaultSettings){
        if(localStorage.getItem(setting) == null) localStorage.setItem(setting, defaultSettings[setting]);
    }

    settingsBox.appendChild(createCheckbox(
        'Preload Embeds',
        'Scans all media in the page for embeds when the page loads.',
        function(){
            localStorage.setItem('4chan-preload-embeds', this.checked);
        },
        localStorage.getItem('4chan-preload-embeds') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    settingsBox.appendChild(createCheckbox(
        'Loop Video',
        'Make video loop.',
        function(){
            localStorage.setItem('4chan-loop-video', this.checked);
        },
        localStorage.getItem('4chan-loop-video') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    settingsBox.appendChild(createCheckbox(
        'Loop Audio',
        'Make audio loop.',
        function(){
            localStorage.setItem('4chan-loop-audio', this.checked);
        },
        localStorage.getItem('4chan-loop-audio') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    settingsBox.appendChild(createCheckbox(
        'Float Images',
        'Make image embeds movable and zoomable.',
        function(){
            localStorage.setItem('4chan-float-embeds', this.checked);
        },
        localStorage.getItem('4chan-float-embeds') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    settingsBox.appendChild(createCheckbox(
        'Load File Embeds',
        'Load embeds from files.',
        function(){
            localStorage.setItem('4chan-load-file-embeds', this.checked);
        },
        localStorage.getItem('4chan-load-file-embeds') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    settingsBox.appendChild(createCheckbox(
        'Load Catbox Embeds',
        'Load embeds from catbox IDs in filenames.',
        function(){
            localStorage.setItem('4chan-load-catbox-embeds', this.checked);
        },
        localStorage.getItem('4chan-load-catbox-embeds') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    settingsBox.appendChild(createCheckbox(
        'Load Hash Embeds',
        'Load embeds from MD5 hash filenames.',
        function(){
            localStorage.setItem('4chan-load-hash-embeds', this.checked);
        },
        localStorage.getItem('4chan-load-hash-embeds') == 'true'
    ));
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    const hashSourcesBox = document.createElement('div');
    hashSourcesBox.style.backgroundColor = 'dimgray';
    hashSourcesBox.style.marginLeft = hashSourcesBox.style.marginRight = '10px';
    for(let hashSource of defaultHashSources){
        if(localStorage.getItem('4chan-load-hash-source-' + hashSource.name) == null) localStorage.setItem('4chan-load-hash-source-' + hashSource.name, true);
        let hashSourceSetting = createCheckbox(
            hashSource.name,
            'Load hash embeds from ' + hashSource.name,
            function(){
                localStorage.setItem('4chan-load-hash-source-' + hashSource.name, this.checked);
            },
            localStorage.getItem('4chan-load-hash-source-' + hashSource.name) == 'true'
        );
        hashSourcesBox.appendChild(hashSourceSetting);
        hashSourcesBox.insertAdjacentHTML('beforeend', '<br>');
    }
    settingsBox.appendChild(hashSourcesBox);
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    const hashBlacklistTitle = document.createElement('h4');
    hashBlacklistTitle.style.margin = '0px';
    hashBlacklistTitle.textContent = 'Hash Tag Warnlist';
    hashBlacklistTitle.title = 'List of tags that a hash embed should warn the user for.';
    settingsBox.appendChild(hashBlacklistTitle);
    const hashBlacklist = document.createElement('textarea');
    hashBlacklist.value = localStorage.getItem('4chan-hash-tag-blacklist') ?? '';
    hashBlacklist.onchange = function(){
        localStorage.setItem('4chan-hash-tag-blacklist', hashBlacklist.value);
    }
    settingsBox.appendChild(hashBlacklist);
    settingsBox.insertAdjacentHTML('beforeend', '<br>');

    setMovable(settingsBox, settingsTitle);

    return settingsBox;
}

const CRC32 = (function(){
    var table = new Uint32Array(256);
    for(var i=256; i--;){
        var tmp = i;

        for(var k=8; k--;){
            tmp = tmp & 1 ? 3988292384 ^ tmp >>> 1 : tmp >>> 1;
        }

        table[i] = tmp;
    }

    /**
     * Calculates CRC-32
     * @param {Uint8Array}   data Text byte length limit
     * @returns {Uint8Array} Return of the CRC
     */
    return function(data){
        var crc = -1;

        for(var i=0, l = data.length; i < l; i++){
            crc = crc >>> 8 ^ table[ crc & 255 ^ data[i] ];
        }

        crc = (crc ^ -1) >>> 0;
        return Uint8Array.from([crc >> 24 & 0xFF, crc >> 16 & 0xFF, crc >> 8 & 0xFF, crc & 0xFF]);
    };
})();

/**
 * Compares two Uint8Arrays
 * @param {Uint8Array} array1
 * @param {Uint8Array} array2
 * @returns {boolean}  Whether the arrays are the same
 */
 function compareUint8Array(array1, array2){
     if(array1.length != array2.length) return false;
    for(let i = 0; i < array1.length; i++){
        if(array1[i] != array2[i]) return false;
    }
    return true;
}


class PNGChunk{
    /**
     * Parse a PNG Chunk
     * @param {Uint8Array} array The chunk content (size, type, data and CRC);
     */
    constructor(array){
        this.array = array;

        this.length = PNGChunk.testLength(array, 0);

        const decoder = new TextDecoder();
        this.typeArrray = array.subarray(4, 8);
        this.type = decoder.decode(this.typeArrray);

        this.data = array.subarray(8, 8 + this.length);

        this.crc = array.subarray(8 + this.length, 8 + this.length + 4);

        this.crcCorrect = compareUint8Array(CRC32(array.subarray(4, 8 + this.length)), this.crc);
    }

    /**
     * Tests the length of a PNG chunk
     * @param {Uint8Array} array The array in which the chunk exists
     * @param {number}     index The index in the array at which the chunk starts
     * @returns {number}   Length of the chunk data
     */
    static testLength(array, index){
        const lengthArray = array.subarray(index, index + 4);
        return (lengthArray[0] << 24) | (lengthArray[1] << 16) | (lengthArray[2] << 8) | lengthArray[3];
    }

    /**
     * Creates a new PNG chunk, a copy of the buffer will be created
     * @param {string}     type The type of the chunk
     * @param {Uint8Array} data The data to put in the chunk
     * @returns {PNGChunk} The created PNG chunk
     */
    static create(type, data){
        const encoder = new TextEncoder()
        const typeArray = encoder.encode(type);
        if(typeArray.length != 4) return null;

        const chunkArray = new Uint8Array(data.length + 12);

        chunkArray[0] = data.length >> 24 & 0xFF;
        chunkArray[1] = data.length >> 16 & 0xFF;
        chunkArray[2] = data.length >> 8 & 0xFF;
        chunkArray[3] = data.length & 0xFF;

        chunkArray.set(typeArray, 4);

        chunkArray.set(data, 8);

        const crc = CRC32(chunkArray.subarray(4, 8 + data.length));
        chunkArray.set(crc, 8 + data.length);

        return new PNGChunk(chunkArray);
    }
}

const maxChunkDataSize = 2**23;

class PNGChunkStream{
    /**
     * Callback for each PNG chunk
     * @callback chunkCallback
     * @param {PNGChunk} chunk - The PNG chunk
     */

    /**
     * Create PNG stream parser
     * @param {chunkCallback} callback - Callback for each PNG chunk
     */
    constructor(callback){
        this.pngHeader = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
        this.callback = callback;
        this._resetForChunk();
        this.idx = 0;
    }

    _resetForChunk(){
        this.state = 0;

        this.lengthIdx = 0;
        this.length = 0;

        this.typeIdx = 0;
        this.type = '';

        this.dataIdx = 0;

        this.crcIdx = 0;
        this.crc = undefined;

        this.data = undefined;
    }

    /**
     * Write data to the parser
     * @param {Uint8Array} data - Data to write
     */
    write(data){
        if(this.state < 0) throw "Invalid PNG";
        for(let i = 0; i < data.length; i++, this.idx++){
            let byte = data[i];
            if(this.idx < 8){
                if(byte != this.pngHeader[this.idx]){
                    this.state = -1;
                    throw "Invalid PNG header";
                }
            }else{
                switch(this.state){
                    case 0: // reading length
                        this.length |= byte << (8 * (3 - this.lengthIdx));
                        this.lengthIdx++;
                        if(this.lengthIdx >= 4){
                            if(this.length > maxChunkDataSize){
                                this.state = -1;
                                throw "Too big PNG chunk data size";
                            }
                            this.data = new Uint8Array(this.length + 4);
                            this.state++;
                        }
                        break;
                    case 1: // reading type
                        this.type += String.fromCharCode(byte);
                        this.data[this.typeIdx] = byte;
                        this.typeIdx++;
                        if(this.typeIdx >= 4) this.state++;
                        break;
                    case 2: // reading data
                        this.data[this.dataIdx + 4] = byte;
                        this.dataIdx++;
                        if(this.dataIdx >= this.length){
                            this.crc = new Uint8Array(4);
                            this.state++;
                        }
                        break;
                    case 3: // reading CRC
                        this.crc[this.crcIdx] = byte;
                        this.crcIdx++;
                        if(this.crcIdx >= 4){
                            if(compareUint8Array(this.crc, CRC32(this.data))){
                                const chunk = PNGChunk.create(this.type, this.data.subarray(4));
                                this.callback(chunk);
                                this._resetForChunk();
                            }else{
                                this._resetForChunk();
                                throw "CRC for chunk does not match";
                            }
                        }
                        break;
                }
            }
        }
    }
}

class PNG{
    /**
     * Create a PNG, a copy of the buffer will be created
     * @param {Uint8Array} array Data to load the PNG from
     */
    constructor(array){
        this.header = new Uint8Array([0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A]);
        this.initialized = true;
        for(let i = 0; i < this.header.length; i++){
            if(array[i] != this.header[i]){
                throw new Error("Not a PNG file");
            }
        }
        
        this.chunks = [];
        for(let i = 8; i < array.length;){
            let chunkLength = PNGChunk.testLength(array, i) + 12;
            let chunk = new PNGChunk(array.slice(i, i + chunkLength));
            if(!chunk.crcCorrect){
                throw new Error('CRC incorrect');
            }
            if(chunk.type == 'IEND'){
                this.endChunk = chunk;
            }else{
                this.chunks.push(chunk);
            }
            i += chunkLength;
        }
    }

    /**
     * Exports the PNG file
     * @returns {Uint8Array} The exported PNG file
     */
    export(){
        let totalLength = this.header.length + this.endChunk.array.length;
        for(let chunk of this.chunks) totalLength += chunk.array.length;

        const result = new Uint8Array(totalLength);

        let pos = 0;
        result.set(this.header, 0);
        pos = this.header.length;

        for(let i = 0; i < this.chunks.length; i++){
            result.set(this.chunks[i].array, pos);
            pos += this.chunks[i].array.length;
        }

        result.set(this.endChunk.array, pos);

        return result;
    }
}

class VINTStream{
    /**
     * Callback for when the VINT is finished
     * @callback vintCallback
     * @param {number} value - Value of the VINT
     * @param {number} width - The width of the VINT
     * @param {Uint8Array} leftover - The leftover data that wasn't part of the VINT
     */

    /**
     * Create VINT stream parser
     * @param {vintCallback} resolve - Callback for when the VINT is finished
     */
    constructor(resolve){
        this.resolve = resolve;
        this.state = 0;
        this.width = 0;
        this.byteIdx = 0;
    }

    write(data){
        // loop through each byte
        for(let i = 0; i < data.length; i++){
            let byte = data[i];

            // loop through each bit
            for(let b = 7; b >= 0; b--){
                let bit = byte >> b & 1;

                // if the bits string is undefined that means that we're still counting the VINT_WIDTH
                if(this.bits == undefined){
                    if(bit == 0){
                        this.width++;
                    }else{
                        this.width++;
                        // if we encounter a 1 that means that we reached end VINT_MARKER bit so we set the string to start collecting VINT_DATA bits
                        this.bits = '';
                    }
                }else{
                    this.bits += String(bit);
                }
            }

            this.byteIdx++;

            // the VINT_WIDTH is larger than 8 so we need to read more bytes
            if(this.width == 0) continue;

            // if we processed the last byte of the VINT we can resolve
            if(this.byteIdx >= this.width){
                const value = parseInt(this.bits, 2);
                const leftover = data.subarray(i+1);
                this.resolve(value, this.width, leftover);
                return;
            }
        }
    }
}

function concatUint8Arrays(arrays){
    let size = 0;
    for(let arr of arrays) size += arr.byteLength;

    const result = new Uint8Array(size);

    let offset = 0;
    for (let arr of arrays) {
        result.set(arr, offset);
        offset += arr.byteLength;
    }

    return result;
}

/** Stream EBML data and get callbacks for for elements */
class EBMLStream{
    /**
     * Callback to fire when an ID was parsed
     * @callback idCallback
     * @param {number} id - ID of the parsing element
     * @returns {boolean} stop - Return true to terminate parsing
     */

    /**
     * Callback to fire when data size was parsed
     * @callback sizeCallback
     * @param {number} size - Size of the parsing element
     * @returns {boolean} stop - Return true to terminate parsing
     */

    /**
     * Callback to fire when data was parsed
     * @callback dataCallback
     * @param {Uint8Array} data - Data of the parsing elemenet
     * @returns {boolean} stop - Return true to terminate parsing
     */

    /**
     * Create an EBML stream parser
     * @param {idCallback} idCallback - Callback to fire when an ID was parsed
     * @param {sizeCallback} sizeCallback - Callback to fire when data size was parsed
     * @param {dataCallback} dataCallback - Callback to fire when data was parsed
     */
    constructor(idCallback, sizeCallback, dataCallback){
        this.idCallback = idCallback;
        this.sizeCallback = sizeCallback;
        this.dataCallback = dataCallback;
        this.state = 0;
    }

    /**
     * Write data to the stream
     * @param {Uint8Array} data - Data to write to the stream
     */
    write(data){
        const that = this;
        if(this.state == 0){
            if(this.vintID == undefined) this.vintID = new VINTStream(function(result, width, leftover){
                if(that.idCallback) that.idCallback(result);
                that.state++;
                delete that.vintID;
                if(leftover.length > 0) that.write(leftover);
            });
            this.vintID.write(data);
        }else if(this.state == 1){
            if(this.vintSize == undefined) this.vintSize = new VINTStream(function(result, width, leftover){
                that.dataSize = result;
                if(that.sizeCallback) that.sizeCallback(result);
                that.state++;
                delete that.vintSize;
                that.dataIdx = 0;
                if(leftover.length > 0) that.write(leftover);
            });
            this.vintSize.write(data);
        }else{
            const dataLeft = this.dataSize - this.dataIdx;
            const dataPart = data.subarray(0, dataLeft);
            const leftover = data.subarray(dataLeft)

            if(this.dataCallback) this.dataCallback(dataPart);

            this.dataIdx += dataPart.length;
            if(this.dataIdx >= this.dataSize){
                this.state = 0;
            }

            if(leftover.length > 0) this.write(leftover);
        }
    }
}

function createVINT(num){
    if(num == 0) return Uint8Array.from([128]);
    let bits = 0;
    let n = num;
    while(n > 0){
        bits++;
        n >>>= 1;
    }
    let octets = Math.ceil(bits / 7);

    let vintArr = new Uint8Array(octets);
    vintArr[0] = 1 << (8 - octets);
    for(let i = 0; i < octets; i++){
        vintArr[i] |= num >> (8 * (octets - i - 1));
    }
    return vintArr;
}

class EBMLChunk{
    /**
     * Create an EBML chunk
     * @param {number} id - EBML ID
     * @param {Uint8Array} data - EBML data
     */
    constructor(id, data){
        this.id = id;
        this.data = data;
    }

    /**
     * Exports the EBML chunk
     * @returns {Uint8Array} The exported EBML chunk
     */
    export(){
        const idVint = createVINT(this.id);
        const sizeVint = createVINT(this.data.length);
        return concatUint8Arrays([idVint, sizeVint, this.data]);
    }
}

class EBML{
    /**
     * Parse EBML
     * @param {Uint8Array} data - EBML Data to parse
     */
    constructor(data){
        this.elements = [];
        let leftover = data;
        while(leftover.length > 0){
            let id, size, data;
            new VINTStream(function(val, w, left){
                id = val;
                leftover = left;
            }).write(leftover);
            new VINTStream(function(val, w, left){
                size = val;
                leftover = left;
            }).write(leftover);
            data = leftover.subarray(0, size);
            leftover = leftover.subarray(size);
            this.elements.push(new EBMLChunk(id, data));
        }
    }

    static create(elements){
        const ebml = new EBML(new Uint8Array());
        ebml.elements = elements;
        return ebml;
    }

    /**
     * Exports the EBML data
     * @returns {Uint8Array} The exported EBML data
     */
    export(){
        return concatUint8Arrays(this.elements.map(elem => elem.export()));
    }
}

const httpRequest = typeof GM_xmlhttpRequest != 'undefined' ? GM_xmlhttpRequest : (GM ? GM.xmlHttpRequest : GM_xmlhttpRequest);

function fetchBlob(url){
    return new Promise((resolve, reject)=>{
        httpRequest({
            method: "GET",
            url,
            responseType: 'blob',
            onload: function(response) {
                resolve(response.response);
            },
            onerror: reject
          });
    });
}

function fetchArrayBuffer(url){
    return new Promise((resolve, reject)=>{
        httpRequest({
            method: "GET",
            url,
            responseType: 'arraybuffer',
            onload: function(response) {
                resolve(response.response);
            },
            onerror: reject
          });
    });
}

function fetchJSON(url){
    return new Promise((resolve, reject)=>{
        httpRequest({
            method: "GET",
            url,
            responseType: 'json',
            onload: function(response) {
                resolve(response.response);
            },
            onerror: reject
          });
    });
}

function fetchHeaders(url){
    return new Promise((resolve, reject)=>{
        httpRequest({
            method: "HEAD",
            url,
            responseType: '',
            onload: function(response) {
                resolve(response);
            },
            onerror: reject
          });
    });
}

const fileTypes = [{
    magicNumber: [0x1A, 0x45, 0xDF, 0xA3],
    elem: 'video',
    mime: 'video/webm',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0, 0, 0, -1, 0x66, 0x74, 0x79, 0x70, 0x69, 0x73, 0x6F],
    elem: 'video',
    mime: 'video/mp4',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0, 0, 0, -1, 0x66, 0x74, 0x79, 0x70, 0x6D, 0x70, 0x34],
    elem: 'video',
    mime: 'video/mp4',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0, 0, 0, -1, 0x66, 0x74, 0x79, 0x70, 0x71, 0x74],
    elem: 'video',
    mime: 'video/mov',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0x4F, 0x67, 0x67, 0x53],
    elem: 'audio',
    mime: 'audio/ogg',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0x49, 0x44, 0x33],
    elem: 'audio',
    mime: 'audio/mpeg',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0xFF, 0xFB],
    elem: 'audio',
    mime: 'audio/mpeg',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0x66, 0x4C, 0x61, 0x43],
    elem: 'audio',
    mime: 'audio/flac',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0x52, 0x49, 0x46, 0x46, -1, -1, -1, -1, 0x57, 0x41, 0x56, 0x45],
    elem: 'audio',
    mime: 'audio/wav',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0, 0, 0, -1, 0x66, 0x74, 0x79, 0x70, 0x4D, 0x34, 0x41],
    elem: 'audio',
    mime: 'audio/mp4',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0, 0, 0, -1, 0x66, 0x74, 0x79, 0x70, 0x64, 0x61, 0x73, 0x68],
    elem: 'audio',
    mime: 'audio/mp4',
    attributes: {'controls': '', 'autoplay': ''}
}, {
    magicNumber: [0x52, 0x49, 0x46, 0x46, -1, -1, -1, -1, 0x57, 0x45, 0x42, 0x50],
    elem: 'img',
    mime: 'image/webp',
    attributes: {}
}, {
    magicNumber: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A],
    elem: 'img',
    mime: 'image/png',
    attributes: {}
}, {
    magicNumber: [0xFF, 0xD8],
    elem: 'img',
    mime: 'image/jpeg',
    attributes: {}
}, {
    magicNumber: [0x47, 0x49, 0x46, 0x38],
    elem: 'img',
    mime: 'image/gif',
    attributes: {}
}, {
    magicNumber: [0x3C, 0x3F, 0x78, 0x6D, 0x6C],
    elem: 'img',
    mime: 'image/svg+xml',
    attributes: {}
}, {
    magicNumber: [0x3C, 0x73, 0x76, 0x67],
    elem: 'img',
    mime: 'image/svg+xml',
    attributes: {}
}, {
    magicNumber: [0, 0, 0, -1, 0x66, 0x74, 0x79, 0x70, 0x61, 0x76, 0x69, 0x66],
    elem: 'img',
    mime: 'image/avif',
    attributes: {}
}, {
    magicNumber: [0x68, 0x74, 0x74, 0x70, 0x3A, 0x2F, 0x2F],
    elem: 'a',
    mime: 'text/plain',
    attributes: {'target': '_blank'}
}, {
    magicNumber: [0x68, 0x74, 0x74, 0x70, 0x73, 0x3A, 0x2F, 0x2F],
    elem: 'a',
    mime: 'text/plain',
    attributes: {'target': '_blank'}
}, {
    magicNumber: [0x6D, 0x61, 0x67, 0x6E, 0x65, 0x74, 0x3A],
    elem: 'a',
    mime: 'text/magnet',
    attributes: {}
}];

function getFileType(fileData){
    for(type of fileTypes){
        let match = true;
        if(fileData.length < type.magicNumber.length) continue; // file is shorter than the header we're testing
        for(let i = 0; i < type.magicNumber.length; i++){
            if(type.magicNumber[i] < 0) continue; // Allow for unspecified parts of file headers
            if(type.magicNumber[i] != fileData[i]){
                match = false;
                break;
            }
        }
        if(match) return type;
    }
    return;
}

let lastZIndex = 1;
function setMovable(element, handle, zoomable){
    let dragging = false;
    let offsetX, offsetY;
    handle.onpointerdown = function(event){
        if(event.button != 0) return;
        event.preventDefault();
        dragging = true;
        offsetX = event.layerX;
        offsetY = event.layerY;
        lastZIndex++;
        this.style.zIndex = lastZIndex;
    }
    function handleMove(event){
        if(!dragging) return;
        element.style.right = '';
        if(element.style.position == 'fixed'){
            element.style.left = event.clientX - offsetX + 'px';
            element.style.top = event.clientY - offsetY + 'px';
        }else{
            element.style.left = event.pageX - offsetX + 'px';
            element.style.top = event.pageY - offsetY + 'px';
        }
    }
    window.addEventListener('pointermove', handleMove);
    window.addEventListener('wheel', handleMove);
    function stopDrag(){
        dragging = false;
    }
    window.addEventListener('pointerup', stopDrag);

    if(zoomable){
        let initialWidth = element.clientWidth;
        let initialHeight = element.clientHeight;
        let zoomLevel = 1;
        element.onwheel = function(event){
            if(dragging) return;
            event.preventDefault();
            zoomLevel *= 2 ** (-event.deltaY / 1000);

            const dWidth = zoomLevel * initialWidth - element.clientWidth;
            const dHeight = zoomLevel * initialHeight - element.clientHeight;

            element.style.right = element.style.maxWidth = element.style.maxHeight = '';

            element.style.left = event.pageX - event.layerX - event.layerX / element.clientWidth * dWidth + 'px';
            element.style.top = event.pageY - event.layerY - event.layerY / element.clientHeight * dHeight + 'px';

            element.style.width = zoomLevel * initialWidth + 'px';
        }
    }
}

function createEmbedElement(fileData, postContainer, filename, className, forceDL){
    let fileType = getFileType(fileData);

    const payloadBlob = new Blob([fileData], {type: fileType ? fileType.mime : 'application/octet-stream'});
    const payloadURL = URL.createObjectURL(payloadBlob);

    if(fileType == undefined || forceDL){
        const downloadLink = document.createElement('a');
        downloadLink.download = filename != undefined ? filename : '';
        downloadLink.href = payloadURL;
        document.body.appendChild(downloadLink);
        downloadLink.click();
        downloadLink.remove();
        return;
    }

    const embedElem = document.createElement(fileType.elem);
    if(filename != undefined) embedElem.title = filename;
    for(let attribute in fileType.attributes){
        if(attribute == 'controls'){
            embedElem.volume = localStorage.getItem('4chan-volume') ?? 0.5;
            embedElem.onvolumechange = function(){
                localStorage.setItem('4chan-volume', embedElem.volume);
            }
        }
        embedElem.setAttribute(attribute, fileType.attributes[attribute]);
    }

    if(fileType.elem == 'a'){
        const decodedURL = new TextDecoder().decode(fileData);
        embedElem.href = decodedURL;
        if(fileType.mime == 'text/magnet'){
            const magnetURL = new URL(decodedURL);
            const magnetName = magnetURL.searchParams.get('dn');
            embedElem.textContent = magnetName ? magnetName + ' 🧲' : '🧲';
        }else{
            embedElem.textContent = decodedURL;
        }
    }else{
        embedElem.src = payloadURL;
    }
    embedElem.className = className;
    embedElem.setAttribute('style', 'max-width: 90vw; max-height: 90vh; touch-action: none;');
    embedElem.style.zIndex = lastZIndex;
    if(localStorage.getItem('4chan-loop-video') == 'true' && fileType.elem == 'video') embedElem.setAttribute('loop', '');
    if(localStorage.getItem('4chan-loop-audio') == 'true' && fileType.elem == 'audio') embedElem.setAttribute('loop', '');
    if(localStorage.getItem('4chan-float-embeds') == 'true' && fileType.elem == 'img'){
        embedElem.style.position = 'absolute';
        embedElem.style.right = '0px';
        embedElem.style.top = document.documentElement.scrollTop + 'px';
        embedElem.onload = function(){
            setMovable(embedElem, embedElem, true);
        }
        postContainer.getElementsByClassName('post')[0].prepend(embedElem);
    }else{
        postContainer.getElementsByClassName('post')[0].appendChild(embedElem);
    }
}

function setPNGDecode(postContainer, decodeButton, url, forceDL){
    let loading = false;
    decodeButton.onclick = async function(){
        const foundEmbed = postContainer.getElementsByClassName('decoded-embed')[0];
        if(foundEmbed != undefined && !forceDL){
            if(foundEmbed.style.display == ''){
                foundEmbed.style.display = 'none';
                if(foundEmbed.controls) foundEmbed.pause();
                this.style.fontWeight = '';
            }else{
                foundEmbed.style.display = '';
                this.style.fontWeight = 'bold';
            }
            return;
        }
        if(loading) return;
        loading = true;

        console.info('Decoding', url);

        const response = await fetchBlob(url).catch(err=>{
            throw err;
        });
        if(response == undefined) return;

        const fileStream = response.stream();
        const fileReader = fileStream.getReader();

        let lastIDATData;
        const chunkStream = new PNGChunkStream(function(chunk){
            if(chunk.type == 'IDAT') lastIDATData = chunk.data;
        });

        while(true){
            let fileChunk = await fileReader.read();
            if(fileChunk.value == undefined) break;
            chunkStream.write(fileChunk.value);
            if(fileChunk.done) break;
        }

        const filenameSize = lastIDATData[0] | (lastIDATData[1] << 8) | (lastIDATData[2] << 16) | (lastIDATData[3] << 24);
        const filenameBin = lastIDATData.slice(4, 4 + filenameSize);
        const filenameDecoder = new TextDecoder('utf-8');
        const filename = filenameDecoder.decode(filenameBin);
        const fileData = lastIDATData.slice(4 + filenameSize);

        createEmbedElement(fileData, postContainer, filename, 'decoded-embed', forceDL);
        this.style.fontWeight = 'bold';
    }
}

function extractFromWebM(fileArr){
    const fileEBML = new EBML(fileArr);

    const segmentsElement = fileEBML.elements.find(element => element.id == 139690087);
    if(!segmentsElement) return;
    const segmentsEBML = new EBML(segmentsElement.data);
    
    const tagsElement = segmentsEBML.elements.find(element => element.id == 39109479);
    if(!tagsElement) return;
    const tagsEBML = new EBML(tagsElement.data);
    
    let tagData;
    let filename;
    for(tagElement of tagsEBML.elements){
        if(tagElement.id != 13171) continue;

        const tagEBML = new EBML(tagElement.data);

        const simpleTags = tagEBML.elements.filter(element => element.id == 10184);
        for(let simpleTag of simpleTags){
            const simpleTagEBML = new EBML(simpleTag.data);
            const nameTag = simpleTagEBML.elements.find(element => element.id == 1443);
            if(nameTag == undefined) continue;
            let tagName = new TextDecoder().decode(nameTag.data);
            if(tagName == 'COOM'){
                const binaryTag = simpleTagEBML.elements.find(element => element.id == 1157);
                if(binaryTag == undefined) continue;
                tagData = binaryTag.data;
            }else if(tagName == 'COOM_FILENAME'){
                const stringTag = simpleTagEBML.elements.find(element => element.id == 1159);
                if(stringTag == undefined) continue;
                filename = new TextDecoder().decode(stringTag.data);
            }
        }
    
    }
    if(tagData == undefined) return;
    return {fileData: tagData, filename};
}

function setWebMDecode(postContainer, decodeButton, url, forceDL){
    let loading = false;
    decodeButton.onclick = async function(){
        const foundEmbed = postContainer.getElementsByClassName('decoded-embed')[0];
        if(foundEmbed != undefined && !forceDL){
            if(foundEmbed.style.display == ''){
                foundEmbed.style.display = 'none';
                if(foundEmbed.controls) foundEmbed.pause();
                this.style.fontWeight = '';
            }else{
                foundEmbed.style.display = '';
                this.style.fontWeight = 'bold';
            }
            return;
        }
        if(loading) return;
        loading = true;

        console.info('Decoding', url);

        const response = await fetchArrayBuffer(url).catch(err=>{
            throw err;
        });
        if(response == undefined) return;

        const fileArr = new Uint8Array(response);

        const {fileData, filename} = extractFromWebM(fileArr);

        createEmbedElement(fileData, postContainer, filename, 'decoded-embed', forceDL);
        this.style.fontWeight = 'bold';
    }
}

function setHashDecode(postContainer, decodeButton, url, forceDL){
    let loading = false;
    decodeButton.onclick = async function(){
        const foundEmbed = postContainer.getElementsByClassName('decoded-hash-embed')[0];
        if(foundEmbed != undefined && !forceDL){
            if(foundEmbed.style.display == ''){
                foundEmbed.style.display = 'none';
                if(foundEmbed.controls) foundEmbed.pause();
                this.style.fontWeight = '';
            }else{
                foundEmbed.style.display = '';
                this.style.fontWeight = 'bold';
            }
            return;
        }
        if(loading) return;
        loading = true;

        const fileBuffer = await fetchArrayBuffer(url);
        const fileData = new Uint8Array(fileBuffer);

        createEmbedElement(fileData, postContainer, url.split('/').pop().split('.')[0], 'decoded-hash-embed', forceDL);
        this.style.fontWeight = 'bold';
    }
}

function setCatboxDecode(postContainer, decodeButton, url, forceDL){
    let loading = false;
    decodeButton.onclick = async function(){
        const foundEmbed = postContainer.getElementsByClassName('decoded-catbox-embed')[0];
        if(foundEmbed != undefined && !forceDL){
            if(foundEmbed.style.display == ''){
                foundEmbed.style.display = 'none';
                if(foundEmbed.controls) foundEmbed.pause();
                this.style.fontWeight = '';
            }else{
                foundEmbed.style.display = '';
                this.style.fontWeight = 'bold';
            }
            return;
        }
        if(loading) return;
        loading = true;

        const fileBuffer = await fetchArrayBuffer(url);
        const fileData = new Uint8Array(fileBuffer);

        createEmbedElement(fileData, postContainer, url.split('/').pop(), 'decoded-catbox-embed', forceDL);
        this.style.fontWeight = 'bold';
    }
}

function createLoadButton(postContainer, url, type, styleAddition, title){
    const decodeButton = document.createElement('a');
    if(title != undefined) decodeButton.title = title;

    const downloadButton = document.createElement('a');
    if(title != undefined) downloadButton.title = title;
    downloadButton.className = 'fa fa-download';

    let decodeName = 'Decode Embed';
    if(type == 'png'){
        setPNGDecode(postContainer, decodeButton, url);
        setPNGDecode(postContainer, downloadButton, url, true);
    }else if(type == 'webm'){
        setWebMDecode(postContainer, decodeButton, url);
        setWebMDecode(postContainer, downloadButton, url, true);
    }else if(type == 'hash'){
        decodeName = 'Show Hash Embed';
        setHashDecode(postContainer, decodeButton, url);
        setHashDecode(postContainer, downloadButton, url, true);
    }else if(type == 'catbox'){
        decodeName = 'Show Catbox Embed';
        setCatboxDecode(postContainer, decodeButton, url);
        setCatboxDecode(postContainer, downloadButton, url, true);
    }

    decodeButton.textContent = decodeName;
    decodeButton.setAttribute('style', `${styleAddition} margin-left: 5px; cursor: pointer;`);
    downloadButton.setAttribute('style', `${styleAddition} margin-left: 5px; cursor: pointer;`);

    const fileInfo = postContainer.getElementsByClassName('file')[0];
    
    fileInfo.appendChild(decodeButton);
    fileInfo.appendChild(downloadButton);
}

async function scanPNG(postContainer, url){
    console.info('Scanning', url, postContainer);

    const response = await fetchBlob(url).catch(err=>{
        throw err;
    });
    if(response == undefined) return;

    const fileStream = response.stream();
    const fileReader = fileStream.getReader();

    let keepStreaming = true;
    let chunkCount = 0;
    const metaDecoder = new TextDecoder();
    const chunkStream = new PNGChunkStream(function(chunk){
        chunkCount++
        if(chunk.type == 'tEXt'){
            if(metaDecoder.decode(chunk.data) == 'CUM\u00000'){
                console.info('Found PNG embed', url, postContainer);
                createLoadButton(postContainer, url, 'png', 'color: #B8860B !important;');
            }
        }
        if(chunkCount > 2) keepStreaming = false;
    });

    while(keepStreaming){
        let fileChunk = await fileReader.read();
        if(fileChunk.value == undefined) break;
        chunkStream.write(fileChunk.value);
        if(fileChunk.done) break;
    }

    fileReader.cancel();
}

async function scanWebM(postContainer, url){
    console.info('Scanning', url, postContainer);

    const response = await fetchBlob(url).catch(err=>{
        throw err;
    });
    if(response == undefined) return;

    const fileStream = response.stream();
    const fileReader = fileStream.getReader();

    let keepStreaming = true;

    const tagStreams = [];
    const tagsStream = new EBMLStream(
        function(id){
            if(id != 13171) return;
            const simpleTagStreams = [];
            let simpleTag = false;
            tagStreams.unshift(new EBMLStream(
                function(id){
                    simpleTag = id == 10184;
                    let tagName = false;
                    let tagName4 = false;
                    let tagNameArr = new Uint8Array();
                    simpleTagStreams.unshift(new EBMLStream(
                        function(id){
                            tagName = id == 1443;
                            // coom data would be ID 1157
                        },
                        function(size){
                            tagName4 = size == 4;
                        },
                        function(data){
                            if(tagName && tagName4){
                                tagNameArr = concatUint8Arrays([tagNameArr, data]);
                                if(tagNameArr.length == 4){
                                    if(new TextDecoder().decode(tagNameArr) == 'COOM'){
                                        keepStreaming = false;
                                        console.info('Found WebM embed', url, postContainer);
                                        createLoadButton(postContainer, url, 'webm', 'color: #B8860B !important;');
                                    }
                                }
                            }
                        }
                    ));
                },
                null,
                function(data){
                    if(simpleTag) simpleTagStreams[0].write(data);
                }
            ));
        },
        null,
        function(data){
            tagStreams[0].write(data);
        }
    );

    let streamingTags = false;
    const segmentStream = new EBMLStream(
        function(id){
            streamingTags = id == 39109479;
            if(id == 256095861) keepStreaming = false;
        },
        null,
        function(data){
            if(streamingTags) tagsStream.write(data);
        }
    );

    let streamingSegments = false;
    const webmStream = new EBMLStream(
        function(id){
            streamingSegments = id == 139690087;
        },
        null,
        function(data){
            if(streamingSegments) segmentStream.write(data);
        }
    );

    while(keepStreaming){
        let fileChunk = await fileReader.read();
        if(fileChunk.value == undefined) break;
        webmStream.write(fileChunk.value);
        if(fileChunk.done) break;
    }

    fileReader.cancel();
}

async function scanHash(postContainer, hash){
    console.info('Scanning', hash, postContainer);

    let foundMatch = false;
    for(let hashSource of defaultHashSources){
        if(localStorage.getItem('4chan-load-hash-source-' + hashSource.name) != 'true') continue;
        
        fetchJSON(hashSource.url + hash).then(response => {
            if(response == '' || response == undefined) return;

            let post;

            if(response.data != undefined) if(response.data[0] != undefined){
                post = response.data[0];
            }

            if(post == undefined) if(response.post != undefined) if(response.post[0] != undefined){
                post = response.post[0];
            }

            if(post == undefined || foundMatch) return;
            if(!post.file_url) return;
            foundMatch = true;
            console.info('Found hash embed match', post, postContainer);

            let tags = [];
            if(typeof post.tags == 'string') tags = post.tags.toLowerCase().split(' ');
            if(typeof post.tags == 'object') tags = post.tags.map(elem => elem.name_en);

            let blacklistedTags = [];
            const blacklistedTagsSetting = localStorage.getItem('4chan-hash-tag-blacklist');
            if(blacklistedTagsSetting){
                for(let tag of blacklistedTagsSetting.replace(/\r/g, '').split('\n')){
                    if(tags.includes(tag)){
                        blacklistedTags.push(tag);
                    }
                }
            }
            createLoadButton(postContainer, post.file_url, 'hash',
                'color: #9932CC !important;' + (blacklistedTags.length > 0 ? ' text-decoration: line-through;' : ''),
                blacklistedTags.length > 0 ? 'Blacklisted tags: ' + blacklistedTags.join(', ') : undefined
            );
        }).catch(err => {});
    }
}

async function scanCatbox(postContainer, mediaName){
    const url = 'https://files.catbox.moe/' + mediaName.match(/^([0-9a-z]{6})(\.mp4|\.mov|\.webm|\.jpg|\.jpeg|\.png|\.apng|\.gif|\.webp|\.avif|\.bmp|\.svg)(?=(\.webm|\.jpg|\.jpeg|\.png|\.gif))/g);
    console.info('Scanning', url, postContainer);

    const headerResult = await fetchHeaders(url);
    if(headerResult.status != 200) return;
    createLoadButton(postContainer, url, 'catbox', 'color: #7FFFD4 !important;');
    // const rawHeaders = headerResult.responseHeaders.replace(/\r/g, '').split('\n');
    // console.info('Catbox headers', url, rawHeaders);
    // const headers = new Headers();
    // for(let header of rawHeaders){
    //     if(!header) continue;
    //     let splitHeader = header.split(': ');
    //     headers.set(splitHeader[0], splitHeader[1]);
    // }
    // console.info(headers);
}

function scan(){
    const scanAll = localStorage.getItem('4chan-preload-embeds') == 'true';

    for(let postContainer of document.getElementsByClassName('postContainer')){
        if(!scanAll) if(postContainer.offsetTop > document.documentElement.scrollTop + document.documentElement.clientHeight || postContainer.offsetTop + postContainer.clientHeight < document.documentElement.scrollTop) continue;

        if(postContainer.getAttribute('scannedembed')) continue;
        postContainer.setAttribute('scannedembed', '1');

        const fileInfo = postContainer.getElementsByClassName('file')[0];
        if(fileInfo == undefined) continue;
        

        let link = fileInfo.getElementsByTagName('a')[0];
        if(link == undefined) continue;

        if(localStorage.getItem('4chan-load-file-embeds') == 'true'){
            if(link.href.toLowerCase().endsWith('.png')) scanPNG(postContainer, link.href);
            if(link.href.toLowerCase().endsWith('.webm')) scanWebM(postContainer, link.href);
        }

        let mediaName = postContainer.getElementsByClassName('download-button')[0]?.download ?? link.title;

        if(localStorage.getItem('4chan-load-hash-embeds') == 'true'){
            let splitMediaName = (mediaName == '' ? link.textContent : mediaName)?.split('.')[0];
            if(/^([a-f0-9]{32}|([a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}))$/gi.test(splitMediaName)) scanHash(postContainer, splitMediaName.replace(/-/g, '').toLowerCase());
        }

        if(localStorage.getItem('4chan-load-catbox-embeds') == 'true')
            if(/^([0-9a-z]{6})(\.mp4|\.mov|\.webm|\.jpg|\.jpeg|\.png|\.apng|\.gif|\.webp|\.avif|\.bmp|\.svg)(?:(\.webm|\.jpg|\.jpeg|\.png|\.gif))$/.test(mediaName)){
                scanCatbox(postContainer, mediaName);
            }
    }
}

function uploadNewFile(){
    return new Promise((resolve, reject)=>{
        const upload = document.createElement('input');
        upload.type = 'file';
        document.body.appendChild(upload);
        upload.onchange = function(){
            upload.remove();
            firstFile = upload.files[0];
            if(firstFile == undefined){
                reject();
            }else{
                resolve(firstFile);
            }
        }
        upload.click();
    });
}

async function createPNGEmbedData(file){
    const embedFileBuffer = await file.arrayBuffer();
    const embedFileData = new Uint8Array(embedFileBuffer);

    const filenameEncoder = new TextEncoder();
    const encodedFilename = filenameEncoder.encode(file.name);

    const dataChunkData = new Uint8Array(encodedFilename.length + embedFileData.length + 4);

    dataChunkData[0] = encodedFilename.length & 0xFF;
    dataChunkData[1] = encodedFilename.length >> 8 & 0xFF;
    dataChunkData[2] = encodedFilename.length >> 16 & 0xFF;
    dataChunkData[3] = encodedFilename.length >> 24 & 0xFF;

    dataChunkData.set(encodedFilename, 4);
    dataChunkData.set(embedFileData, 4 + encodedFilename.length);

    return dataChunkData;
}

function embedWebMData(filename, webm, payload){
    const targets = new EBMLChunk(9152, new Uint8Array());

    const coomNameTag = new EBMLChunk(1443, new TextEncoder().encode('COOM'));
    const coomBinaryTag = new EBMLChunk(1157, payload);
    const coomSimpleTag = new EBMLChunk(10184, concatUint8Arrays([coomNameTag.export(), coomBinaryTag.export()]));

    const filenameNameTag = new EBMLChunk(1443, new TextEncoder().encode('COOM_FILENAME'));
    const filenameStringTag = new EBMLChunk(1159, new TextEncoder().encode(filename));
    const filenameSimpleTag = new EBMLChunk(10184, concatUint8Arrays([filenameNameTag.export(), filenameStringTag.export()]));

    const tag = new EBMLChunk(13171, concatUint8Arrays([targets.export(), coomSimpleTag.export(), filenameSimpleTag.export()]));

    const webmEBML = new EBML(webm);
    const segmentsElement = webmEBML.elements.find(element => element.id == 139690087);
    const segmentsEBML = new EBML(segmentsElement.data);

    let tagsElement = segmentsEBML.elements.find(element => element.id == 39109479);
    if(tagsElement == undefined){
        tagsElement = new EBMLChunk(39109479, tag.export());
        let tracksIdx;
        for(let i = 0; i < segmentsEBML.elements.length; i++){
            if(segmentsEBML.elements[i].id == 106212971){
                tracksIdx = i;
                break;
            }
        }
        if(tracksIdx != undefined){
            segmentsEBML.elements.splice(tracksIdx + 1, 0, tagsElement);
        }else
            segmentsEBML.elements.push(tagsElement);
    }else{
        tagsElement.data = concatUint8Arrays([tag.export(), tagsElement.data]);
    }

    segmentsElement.data = segmentsEBML.export();
    return webmEBML.export();
}

const settingsWindow = createSettings();
document.body.appendChild(settingsWindow);
registerMenuCommand('Settings', function(){
    settingsWindow.style.visibility = '';
    settingsWindow.style.top = 0.5 * document.documentElement.clientHeight - 0.5 * settingsWindow.clientHeight + 'px';
    settingsWindow.style.left = 0.5 * document.documentElement.clientWidth - 0.5 * settingsWindow.clientWidth + 'px';
    console.log(settingsWindow);
});

document.body.onscroll = scan;

document.addEventListener('ThreadUpdate', scan);

let injected = false;
document.addEventListener('QRDialogCreation', event => {
    if(injected) return;
    injected = true;
    const qrDialog = event.target;
    const fileBox = qrDialog.querySelector('#qr-filename-container');
    const img = document.createElement('i');
    img.className = "fa fa-paperclip";
    const attachment = document.createElement('a');
    attachment.appendChild(img);
    fileBox.appendChild(attachment);
    attachment.onclick = async function(){
        const selectedFile = await new Promise((resolve, reject) => {
            document.addEventListener('QRFile', event => resolve(event.detail), { once: true });
            document.dispatchEvent(new CustomEvent('QRGetFile'));
        });
        if(selectedFile == null){
            alert('You need to select a PNG file first');
            return;
        }

        if(selectedFile.type != 'image/png' && selectedFile.type != 'video/webm'){
            alert('Host file is not a PNG or WebM');
            return
        }

        const fileBuffer = await selectedFile.arrayBuffer();
        const fileData = new Uint8Array(fileBuffer);
        // For some reason we need to make a copy or we get a permission error ¯\_(ツ)_/¯
        const dataCopy = new Uint8Array(fileData.length);
        dataCopy.set(fileData);

        const embedFile = await uploadNewFile();

        let finalBlob;
        if(selectedFile.type == 'image/png'){
            const hostPNG = new PNG(dataCopy);

            const textPNGChunk = PNGChunk.create('tEXt', Uint8Array.from([0x43, 0x55, 0x4d, 0x00, 0x30]));
            hostPNG.chunks.splice(1, 0, textPNGChunk);

            const dataPNGChunkData = await createPNGEmbedData(embedFile);
            const dataPNGChunk = PNGChunk.create('IDAT', dataPNGChunkData);
            hostPNG.chunks.push(dataPNGChunk);

            const finalPNGData  = hostPNG.export();
            finalBlob = new Blob([finalPNGData], {type: 'image/png'});
        }else if(selectedFile.type == 'video/webm'){
            const embedFileData = await embedFile.arrayBuffer();
            const embedFileArr = new Uint8Array(embedFileData);

            const finalWebmData = embedWebMData(embedFile.name, dataCopy, embedFileArr)
            finalBlob = new Blob([finalWebmData], {type: 'video/webm'});
        }

        document.dispatchEvent(new CustomEvent('QRSetFile', {
            detail: { file: finalBlob, name: selectedFile.name }
        }));
    }
});

scan();
